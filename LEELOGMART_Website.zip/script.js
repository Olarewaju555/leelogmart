const EXCHANGE_RATE = 1500; // $1 = ₦1500

function addProduct() {
  let products = JSON.parse(localStorage.getItem("products")) || [];

  const usd = document.getElementById("priceUSD").value;
  const naira = usd * EXCHANGE_RATE;

  const product = {
    name: document.getElementById("name").value,
    priceUSD: usd,
    priceNGN: naira,
    desc: document.getElementById("desc").value
  };

  products.push(product);
  localStorage.setItem("products", JSON.stringify(products));
  alert("Product added!");
}

window.onload = function () {
  let products = JSON.parse(localStorage.getItem("products")) || [];
  let container = document.getElementById("products");

  if (container) {
    products.forEach(p => {
      const message = `Hello, I want to buy:\n${p.name}\n₦${p.priceNGN} / $${p.priceUSD}`;

      container.innerHTML += `
        <div style="border:1px solid #ccc; margin:10px; padding:10px; background:white;">
          <h3>${p.name}</h3>
          <p>${p.desc}</p>
          <strong>$${p.priceUSD}</strong><br>
          <strong>₦${p.priceNGN}</strong><br><br>

          <button onclick="payWithPaystack(${p.priceNGN}, '${p.name}')">
            💳 Pay Now
          </button>
          <br><br>
          <a href="https://wa.me/2348107127682?text=${encodeURIComponent(message)}"
             style="background:green;color:white;padding:10px;border-radius:5px;text-decoration:none;">
             📲 Order on WhatsApp
          </a>
        </div>
      `;
    });
  }
};

function payWithPaystack(amount, product) {
  let handler = PaystackPop.setup({
    key: "pk_live_YOUR_PUBLIC_KEY_HERE", // Replace with your Paystack public key
    email: "customer@email.com",
    amount: amount * 100,
    currency: "NGN",
    callback: function (response) {
      alert("Payment successful for " + product);
      alert("✅ Simulated Email/SMS sent to admin for " + product);
    },
    onClose: function () {
      alert("Payment cancelled");
    }
  });
  handler.openIframe();
}
